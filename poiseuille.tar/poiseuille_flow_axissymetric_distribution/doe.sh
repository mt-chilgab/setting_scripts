#!/bin/bash

pwd_=$pwd

SCR_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
Vels=("0.2" "0.8" "1.4" "2.0" "2.6")
Times=("0.005" "0.001" "0.0005" "0.0005" "0.0002")

cd $SCR_DIR

if [ ! -d "./dataset" ];then
	mkdir "./dataset"
elif [ $(ls -lqA "./dataset" | grep -oP '^(?<=total\s)\d+$') -ge 1 ];then
	mkdir "./dataset_old"
	mv "./dataset/*" "./dataset_old"
fi

for i in {0..4}
do
	./Allclean &> /dev/null
	perl -pe "s/\d(\.\d+)*(?=\s)/${Vels[$i]}/ if $. == 26" "./0/U" &> "./dataset/U_"
	perl -pe "s/\d(\.\d+)*(?=;)/${Times[$i]}/ if $. == 28" "./system/controlDict" &> "./dataset/controlDict_"
	mv "./dataset/U_" "./0/U"
	mv "./dataset/controlDict_" "./system/controlDict"
	blockMesh
	checkMesh
	icoFoam
	sample
	if [ ! -f "./postProcessing/sets/0.5/data_U.xy" ];then
		echo "Unable to sample @${Vels[$i]}m/s" &> doe.log
	else
		cp "./postProcessing/sets/0.5/data_U.xy" "./dataset/data${Vels[$i]}"	
	fi
done

perl -pe "s/\d(\.\d+)*(?=\s)/1/ if $. == 26" "./0/U" &> "./0/U_"
perl -pe "s/\d(\.\d+)*(?=;)/0.0005/ if $. == 28" "./system/controlDict" &> "./system/controlDict_"
mv "./0/U_" "./0/U"
mv "./system/controlDict_" "./system/controlDict"

gnuplot plot_
mv "./test.png" /mnt/c/users/grant/desktop

cd $pwd_
